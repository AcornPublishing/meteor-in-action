Template.file.helpers({
  'file': function () {
    return FilesCollection.findOne();
  }
});