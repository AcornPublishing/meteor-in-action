/* globals Song: true */

Song = function Song() {};

Song.prototype.persistFavoriteStatus = function () {
  // something complicated
  throw new Error('not yet implemented');
};