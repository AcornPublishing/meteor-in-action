console.log('server/main.server.js loaded');
console.log("Using the following API Key for Twitter");
console.log(Meteor.settings.oauth.twitter.apikey);