(function(){console.log('common/common.js loaded');

})();
