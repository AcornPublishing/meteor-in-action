(function(){console.log('server/server.js loaded');

})();
