(function(){console.log('assets/assets.js loaded');

})();
